import { RouterModule,Routes } from '@angular/router';

import {ProductListComponent}     from './product-list/product-list.component';
import {ProductDetailComponent}   from './product-detail/product-detail.component';
import {ProductCreateComponent}   from './product-add/product-add.component';
import {ProductUpdateComponent}   from './product-update/product-update.component';
import {ProductDeleteComponent}   from './product-delete/product-delete.component';

import {ShoppingCartComponent}   from './shoppingcart/cart.component';
import {LoginComponent}          from './login/login.component';
import {RegisterComponent}       from './register/register.component';
import {ChangePasswordComponent} from './change-password/changepassword.component';

export const routes: Routes = [
  { path: 'list', component: ProductListComponent },
  { path: 'create', component: ProductCreateComponent },
  { path: 'detail/:productID', component: ProductDetailComponent },
  { path: 'update/:productID', component: ProductUpdateComponent },
  { path: 'delete/:productID', component: ProductDeleteComponent },
  { path: '', redirectTo: 'list', pathMatch:'full' },

  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'changepassword', component: ChangePasswordComponent },
  { path: 'shoppingcart', component: ShoppingCartComponent },
  { path: 'shoppingcart/:username', component: ShoppingCartComponent },
  //{ path: 'usercreate', component: UserCreateComponent },
  //{ path: 'userupdate/:userID', component: UserUpdateComponent },
  //{ path: 'userdelete/:userID', component: UserDeleteComponent }
];
