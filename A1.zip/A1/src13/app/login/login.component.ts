import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

import {ActivatedRoute,Router} from '@angular/router';

import { Claim } from '../objects/claim';
import {UserProfile} from '../objects/userProfile';

import{AuthenticationService} from '../services/authenticationService';
import{UserProfileService} from '../services/userProfileService';


@Component({
            selector: 'login',
            templateUrl: './login.component.html'
          })
 
 export class LoginComponent implements OnInit {

   theCredential: Claim;
   currentProfile:UserProfile;

   
constructor(public router: Router,public location: Location,
            public authSvc: AuthenticationService,public userProfileSvc:UserProfileService) {
} 

ngOnInit(): void { }

 validate(credential) {
    this.theCredential = credential; 
    if(this.authSvc.login(this.theCredential))
    {
    this.userProfileSvc.setProfile(this.theCredential.userName,"ty67","ty678");
    this.currentProfile=this.userProfileSvc.getProfile();
    console.log("In component retrived  current Profile");
    console.log(this.currentProfile);


    //this.shoppingCart.Create(this.theCredential.userName);
    this.router.navigateByUrl("/shoppingcart/"+this.theCredential.userName);
  }
  else{
    console.log("Invalid User");

  }

  }

  back(): void {
    this.location.back();
  }
}