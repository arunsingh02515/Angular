import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';

import { Product } from '../objects/product';

import{ProductHubService} from '../services/productHubService';

@Component({
            selector: 'update',
            templateUrl: './product-update.component.html'
          })
export class ProductUpdateComponent implements OnInit{
    id: number;
    product: Product;
    public products_error:boolean=false;

    constructor(public route: ActivatedRoute, public productHub: ProductHubService,
                public location: Location) {

                console.log(route.params['productID']);
                this.product= new  Product(1,'Balance',"http://localhost:4200/resources/images/flowers/balance.gif",
                                            "red","flower","it is a flower","45",
                                            5,89,"10 days","within 5 hours");
                route.params.subscribe(params => { this.id = params['productID']; }); 
    }

    ngOnInit(): void {
    this.productHub.search(this.id).subscribe(
                                      data=>{this.product=data},
                                      err=>{this.products_error=true;}
                                    )             
    }
  
  submit(form)  {
            this.productHub.update(this.product);
            this.location.back();
  }

  back(): void {
      this.location.back();
  }
} 