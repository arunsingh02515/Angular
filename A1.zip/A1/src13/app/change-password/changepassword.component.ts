import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

import {ActivatedRoute} from '@angular/router';

import{User} from '../objects/user';
import{AuthenticationService} from '../services/authenticationService';


@Component({
  selector: 'changepassword',
  templateUrl: './changepassword.component.html'
})
export class ChangePasswordComponent implements OnInit {
   value: User;
  

  /* constructor() {}*/
  /* constructor(public route: ActivatedRoute, public authHub: AuthenticationService,
              public location: Location) {
  } */

  constructor(public authHub: AuthenticationService) {
  } 

  ngOnInit(): void { }

  validate(form) {
        this.value = form; 
        this.authHub.changePassword(this.value);
        // this.location.back();
  }

  back(): void {
      // this.location.back();
  }
}