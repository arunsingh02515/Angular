
import { Component} from '@angular/core';

@Component({
            selector: 'router-app',
            template: `<router-outlet></router-outlet>`
          })
export class RootComponent {
          query: string;
}
