import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import { Product } from '../objects/product';
import{ProductHubService} from '../services/productHubService';

@Component({
            selector: 'detail',
            templateUrl: './product-detail.component.html'
})
export class ProductDetailComponent implements OnInit {

  id:number;
  product:Product;
  public products_error:boolean=false;

  constructor(private route:ActivatedRoute, private productHub:ProductHubService,
              private location:Location){
     this.product= new  Product(1,'Balance',"http://localhost:4200/resources/images/flowers/balance.gif",
                                "red","flower","it is a flower",
                                "45",5,89,"10 days","within 5 hours");
   
    route.params.subscribe(params => { this.id = params['productID']; });
   }

  ngOnInit():void {
     this.productHub.search(this.id).subscribe(
     data=>{this.product=data},
     err=>{this.products_error=true;}
   )   
 }

 renderProduct(res:any):void{
    this.product=res;
    console.log(res);
    console.log(this.product.title);
 }

 back():void{
   this.location.back();
 }   
}
