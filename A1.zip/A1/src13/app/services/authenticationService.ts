import {Injectable} from '@angular/core';

import { Claim } from '../objects/claim';
import{User} from '../objects/user';

@Injectable()
export class AuthenticationService {
  status:boolean;

  constructor() {
  }
  
  login(claim:Claim):boolean{
    this.status=false;
    if(claim.userName=="ravi" && claim.password=="ravi")
    {
       this.status=true;
    }
    return this.status;  
  }

  changePassword(user:User) { 
       console.log('New Password is' +user.password);
  }

  forgotPassword(user:User) { 
       console.log(user.email +
                   ' your password is reset to  P@ssw0rd123' +user.password);
  }                              
}