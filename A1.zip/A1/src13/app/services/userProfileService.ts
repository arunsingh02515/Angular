import {Injectable} from '@angular/core';
import { UserProfile } from '../objects/userProfile';

@Injectable()
export class UserProfileService {
 
  constructor() {
  }

 setProfile(userName:string, token:string,refreshToken:string):void {
      sessionStorage.setItem('username',userName);
      sessionStorage.setItem('accessToken',token);
      sessionStorage.setItem('refreshToken',refreshToken);
    }                               

  getProfile():UserProfile{
      var theUserProfile= new UserProfile(sessionStorage.getItem('accessToken')!=null,
                                      sessionStorage.getItem('username'),
                                      sessionStorage.getItem('accessToken'),
                                      sessionStorage.getItem('refreshToken'));
      return theUserProfile;
  }

  }