import {Injectable} from '@angular/core';

import{Product} from '../objects/product';
import{User} from '../objects/user';
import{Item} from '../objects/item';


@Injectable()
export class ShoppingCartService {
 
  constructor() {
   }
  
   getAllItems():Item[]{
        var  items=[
          new  Item(new Product(1,'Balance',
                                "http://localhost:4200/resources/images/flowers/balance.gif",
                                "red","flower","it is a flower","45",5,70,
                                "10 days","within 5 hours"),5),
          new  Item( new  Product(6,"Dune",
                                  "http://localhost:4200/resources/images/flowers/dune.gif",
                                  "red","flower","stanza","45",5,50,
                                  "10 days","within 5 hours"),4),
          new  Item(new  Product(4,"Dalma","http://localhost:4200/resources/images/flowers/dalma.gif",
                                  "pink","flower","stanza","45",5,39,
                                  "10 days","within 5 hours"),9),
        ];
        return items;
  }

  getItemsById(item:Item) {             
  }

  addItem(item:Item):void {                                  
  }  

  removeItem(item:Item):void {                                           
 }                              
}