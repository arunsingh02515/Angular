 import {Product} from './product';
 
 export class Item  {
 constructor( public product:Product,public  quantity:number){  }
}
