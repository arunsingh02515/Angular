import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import {ActivatedRoute} from '@angular/router';

import { Product } from '../objects/product';
import{ProductHubService} from '../services/productHubService';

@Component({
  selector: 'create',
  templateUrl: './product-add.component.html'
})
 
 export class ProductCreateComponent implements OnInit {
   value: Product;
   
  constructor(public route: ActivatedRoute, public productHub: ProductHubService,
              public location: Location) {
  } 

  ngOnInit(): void { }

  submit(form) {
      this.value = form; 
      this.productHub.insert(this.value);
      this.location.back();
  }

  back(): void {
      this.location.back();
  }
}