import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

import { Item } from '../objects/item';
import{ShoppingCartService} from '../services/shoppingCartService';


@Component({selector: 'shoppingcart',
            templateUrl: './shoppingCart.component.html' })
export class ShoppingCartComponent implements OnInit {
  items: Item[];
  
  public cartItems_error:boolean=false;
  query:string;
  constructor( private router:Router,
                private cartsvc:ShoppingCartService,
                private route:ActivatedRoute) {
                  this.route
                          .queryParams
                          .subscribe(params => {this.query = params['query']||'';});             
    }

  // constructor(private cartsvc:ShoppingCartService) { }

   ngOnInit() {
      this.items=this.cartsvc.getAllItems();
  }
}