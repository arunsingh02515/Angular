import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import {ActivatedRoute} from '@angular/router';

import { User } from '../objects/user';
import{UserHubService} from '../services/userHubService';

@Component({
            selector: 'register',
            templateUrl: './register.component.html'
})
export class RegisterComponent implements OnInit {
    submitted = false;
    locations = ['Pune','Mumbai','Delhi','Bangalore','Nashik','Chennai'];
    memberShips = [
                    {value:'G',display:'Gold'},
                    {value:'S',display:'Silver'},
                    {value:'P',display:'Platinum'}
    ];
  
    value: User;

  /* constructor() {} */   
  /*constructor(public route: ActivatedRoute, public userHub: UserHubService,
              public location: Location) {} */

  constructor(public userHub: UserHubService) { } 

  ngOnInit(): void { }

  submit(form) {
      this.value = form; 
      this.userHub.insert(this.value);
      //  this.location.back();
  }

  back(): void {
      // this.location.back();
  }
}