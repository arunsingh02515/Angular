import { Component, OnInit } from '@angular/core';
import { Item } from '../objects/item';

@Component({selector: 'shoppingcart',
            templateUrl: './shoppingCart.component.html' })
export class ShoppingCartComponent implements OnInit {
  items: Item[];
  
  public cartItems_error:boolean=false;
  
  constructor() { }

   ngOnInit() {
     
  }
}