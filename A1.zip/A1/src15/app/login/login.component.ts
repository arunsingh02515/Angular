import { Component, OnInit } from '@angular/core';

import { Claim } from '../objects/claim';
 
@Component({
            selector: 'login',
            templateUrl: './login.component.html'
          })
 
 export class LoginComponent implements OnInit {

   theCredential: Claim;

   constructor(){}
 

ngOnInit(): void { }

 validate(credential) {
    this.theCredential = credential; 
  }

  back(): void {
     
  }
}