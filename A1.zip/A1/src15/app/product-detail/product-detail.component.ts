import { Component, OnInit } from '@angular/core';
import { Product } from '../objects/product';
 
@Component({
            selector: 'detail',
            templateUrl: './product-detail.component.html'
})
export class ProductDetailComponent implements OnInit {
  product:Product;
   
  constructor(){
     this.product= new  Product(1,'Balance',"http://localhost:4200/resources/images/flowers/balance.gif",
                                "red","flower","it is a flower",
                                "45",5,89,"10 days","within 5 hours");
   }

  ngOnInit():void { }
 
 }
