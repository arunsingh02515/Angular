import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
 
import { User } from '../objects/user';
 
@Component({
            selector: 'register',
            templateUrl: './register.component.html'
})
export class RegisterComponent implements OnInit {
    submitted = false;
    locations = ['Pune','Mumbai','Delhi','Bangalore','Nashik','Chennai'];
    memberShips = [
                    {value:'G',display:'Gold'},
                    {value:'S',display:'Silver'},
                    {value:'P',display:'Platinum'}
    ];
  
    value: User;

    constructor() {}   

  ngOnInit(): void { }

  submit(form) {
      this.value = form;   
  }

  back(): void {
      
  }
}