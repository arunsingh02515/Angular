import { Component, OnInit } from '@angular/core';
 


import { Product } from '../objects/product';
import{ProductHubService} from '../services/productHubService';

@Component({
  selector: 'list',
  templateUrl: './product-list.component.html'  
})
export class ProductListComponent implements OnInit {
  products: Product[];
  product:Product;
  public products_error:boolean=false;
  query:string;

  constructor(private productHub:ProductHubService) {
  
  }

  ngOnInit() {

     this.productHub.getProducts().subscribe(
       data=>{this.products=data},
       err=>{this.products_error=true;}
      
     )}
}