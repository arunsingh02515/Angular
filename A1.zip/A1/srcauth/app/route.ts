import { RouterModule,Routes } from '@angular/router';

import {HomeComponent}          from './root/HomeComponent';
import {AboutComponent}         from './root/AboutComponent';
import {ContactComponent}       from './root/ContactComponent';
import {ProtectedComponent}     from './root/ProtectedComponent';
import {LoggedInGuard}          from './guards/loggedIn.guard';

export const routes: Routes = [
   { path: '',          redirectTo: 'home', pathMatch: 'full' },
  { path: 'home',      component: HomeComponent },
  { path: 'about',     component: AboutComponent },
  { path: 'contact',   component: ContactComponent },
  { path: 'protected', component: ProtectedComponent,
    canActivate: [LoggedInGuard]}
];
