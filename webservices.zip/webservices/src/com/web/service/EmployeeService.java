package com.web.service;

import java.util.List;

import com.web.domain.Emp;
import com.web.model.EmpDetails;

public interface EmployeeService {
	public List<Emp> getAllEmployee(); 

	public Emp search(int no);
	public void remove(int no);
}
