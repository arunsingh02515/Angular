package com.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.web.dao.EmployeeDAO;
import com.web.domain.Emp;
import com.web.model.EmpDetails;

public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeDAO employeeDao;
	
	public List<Emp> getAllEmployee(){
		//List<EmpDetails> listEmpDetails= new ArrayList<>();
		return employeeDao.getAllEmployee();
		
		
	}

	public Emp search(int no){
		return employeeDao.search(no);
	}
	public void remove(int no){}
}
