package com.web.util;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static ThreadLocal<Session>threadLocal=new ThreadLocal<Session>();
	private static SessionFactory factory;
	static{
		Configuration cfg=null;
		cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		factory=cfg.buildSessionFactory();
}
    public static Session getSession(){
	Session session=null;
		if(threadLocal.get()==null){
    session=factory.openSession();
    threadLocal.set(session);
}
    session=threadLocal.get();
       return session;
}
    public static void closeSession(){
    Session session=null;
    session=threadLocal.get();
    session.close();
    threadLocal.remove();
}
    public static void closeSessionFactory(){
	factory.close();
}
}
