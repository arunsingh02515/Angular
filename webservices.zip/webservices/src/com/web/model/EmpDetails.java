package com.web.model;

public class EmpDetails {
 private int no;
 private String fName;
 private String lName;
 private String mail;
 public EmpDetails(){
	 System.out.println("EmpDetails:0-param constructor");
	  }
 
public int getNo() {
	return no;
}

public void setNo(int no) {
	this.no = no;
}

public String getfName() {
	return fName;
}

public void setfName(String fName) {
	this.fName = fName;
}

public String getlName() {
	return lName;
}

public void setlName(String lName) {
	this.lName = lName;
}

public String getMail() {
	return mail;
}

public void setMail(String mail) {
	this.mail = mail;
}

public String toString(){
	return "EmpDetails[no="+no+ ",fname=" +fName+ ",lname=" +lName+ ",mail=" +mail+"]";
}
}
