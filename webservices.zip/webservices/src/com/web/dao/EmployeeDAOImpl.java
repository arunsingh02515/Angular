package com.web.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.web.util.HibernateUtil;

import javassist.bytecode.Descriptor.Iterator;

import com.web.domain.Emp;
import com.web.model.EmpDetails;

public class EmployeeDAOImpl implements EmployeeDAO{
	  public int register(int no,String fname,String lname,String mail){
      Session session=null;
      Transaction tx=null;
      EmpDetails details=null;
           int id=0;
      session=HibernateUtil.getSession();
      details=new EmpDetails();
      details.setNo(no);
      details.setfName(fname);
      details.setlName(lname);
try{
	  tx=session.beginTransaction();
	  id=(Integer)session.save(details);
      tx.commit();
}
catch(Exception e){
	  tx.rollback();
}
      return id;
	}
	  public List<Emp> getAllEmployee(){
		 // List<Emp> listEmp= new ArrayList<Emp>();
		  Session  session=HibernateUtil.getSession();
		  Query q=session.createQuery("from Emp e");
		 List<Emp>list=  q.getResultList();
		  
		  return list;
	  }
	  public Emp search(int no){
		Session session=null;
		Emp details=null;
		session=HibernateUtil.getSession();
		details=(Emp)session.get(Emp.class,no);
	return details;
	}
	public void remove(int no){
		Session session=null;
		Emp details=null;
		Transaction tx=null;
	     session=HibernateUtil.getSession();
	details=search(no);
if(details!=null){
try{
		tx=session.beginTransaction();
		session.delete(details);
		tx.commit();
	}
catch(Exception e){
		tx.rollback();
		}
     }
   }
}

	
	




