package com.web.dao;

import java.util.List;

import com.web.domain.Emp;

public interface EmployeeDAO {
		
	public List<Emp> getAllEmployee(); 

	public Emp search(int no);
	public void remove(int no);
	}


