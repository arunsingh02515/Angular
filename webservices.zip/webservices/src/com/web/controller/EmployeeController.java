package com.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.web.domain.Emp;
import com.web.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService empService;
	@RequestMapping(value = "/getAllEmp", method = RequestMethod.GET)
	public List<Emp> getAllEmployee(){
		return empService.getAllEmployee();
		
		
	}
	@RequestMapping(value = "/getEmpById", method = RequestMethod.GET)
	public Emp search(int no){
		return empService.search(no);
	}

}
