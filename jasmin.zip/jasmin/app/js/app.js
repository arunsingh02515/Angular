var testAngularApp = angular.module('testAngularApp', []);
/*testAngularApp.directive('nsTextAndSub',function(){
    return {
        restrict:'E',
        templateUrl:'app/js/text-and.html',
        scope:{
            text:"@",
            sub:"@"
        },
        link:function(scope,element,attrs){
            
        }
    }
    
});*/
testAngularApp.controller('testingAngularCtrl',function($rootScope, $scope){
   $scope.title= "Testring Angularjs Application" ;
    $scope.destinations=[];
    $scope.newDestination={
        city:undefined,
        country:undefined
    };
    $scope.addDestination=function(){
        $scope.destinations.push(
         {
             city:$scope.newDestination.city,
             country:$scope.newDestination.country
         }
        )
    }
} );


testAngularApp.directive('nsStateful',function(){
    return {
        restrict: 'A',
        scope :false,
        link:function(scope,element,attrs){
            if(!attrs.nsStateful){
                throw "you must provide a class name in ";
            }
            element.bind('click',function(e){
                scope.$apply(function(){
                    if(!element.hasClass(attrs.nsStateful)){
                        element.addClass(attrs.nsStateful)
                    }
                    else {
                        element.removeClass(attrs.nsStateful)
                    }
             })
            })
        }
    }
})