describe('Testing Angularjs Test suite',function(){
    beforeEach( module('testAngularApp'));
    describe('Testring Angularjs controller',function(){
        var scope,ctrl;
        beforeEach(inject(function($controller,$rootScope){
            scope=$rootScope.$new();
                ctrl=$controller('testingAngularCtrl',{$scope:scope});
            }));
        it('should initialize the title in the scope',function(){
           
            expect(scope.title).toBeDefined();
            expect(scope.title).toBe('Testring Angularjs Application');
        });
        it('should add 2 destination to the destnitation list',function(){
            expect(scope.destinations).toBeDefined();
            
            scope.newDestination={
        city:'london',
        country:'abc'
    };
            scope.addDestination();
            expect(scope.destinations.length).toBe(1);
            expect(scope.destinations[0].country).toBe('abc');
            scope.addDestination();
            expect(scope.destinations.length).toBe(2);
            
        })
    });
    
});