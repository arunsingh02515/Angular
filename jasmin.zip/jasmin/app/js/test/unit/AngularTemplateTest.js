/*describe('Testing Angularjs Test suite',function(){
    var $rootScope,$scope,$compile,el,$el,
        $body=$('body'),
        simpleHtml='<ns-text-and-sub text="{{scopeText}}" sub="{{scopeSub}}"></ns-text-and-sub>';
    beforeEach(function(){
     module('template','testAngularApp');
   inject(function($injector){
       $rootScope=$injector.get('$rootScope');
       $scope=$rootScope.$new();
       $compile=$injector.get('$compile');
       el=$compile(angular.element(simpleHtml))($scope)
   });
          $body.append(el);
        $rootScope.$digest();
        $el=$('.text-and-sub');
    });
    it('should render test ',function(){
     $scope.scopeText='jungle Land'
     $scope.$digest();
        expect($el.find('h3').text()).toEqual('jungle Land');
    });
});*/