
import {Component, OnInit} from '@angular/core';


@Component({
  selector: 'my-app',
  template: '<h1>Hello Angular!</h1>'
})
export class AppComponent implements OnInit {
  
  count: Number;
  data:any;

  ngOnInit() {
        this.count=25;
    }

   setData(){
        this.data={
                    "userId": 23,
                    "id": 1,
                    "firstname": "Ravi",
                    "lastname": "Tambade"
        }
   }
 }