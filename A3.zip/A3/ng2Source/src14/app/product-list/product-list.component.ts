import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';


import { Product } from '../objects/product';
import{ProductHubService} from '../services/productHubService';

@Component({
  selector: 'list',
  templateUrl: './product-list.component.html'  
})
export class ProductListComponent implements OnInit {
  products: Product[];
  

  constructor() {
    this.products = [ 
       new  Product(12,'Balance',"http://localhost:4200/resources/images/flowers/balance.gif",
                     "red","flower","it is a flower","45",5,89,"10 days","within 5 hours"),
       new  Product(13,"Cacharelle","http://localhost:4200/resources/images/flowers/cacharelle.gif",
                     "yellow","flower","stanza","45",5,89,"10 days","within 5 hours"),
       new  Product(14,"Coyota","http://localhost:4200/resources/images/flowers/coyota.jpg",
                     "green","flower","stanza","45",5,89,"10 days","within 5 hours"),
       new  Product(15,"Dalma","http://localhost:4200/resources/images/flowers/dalma.gif",
                    "pink","flower","stanza","45",5,89,"10 days","within 5 hours"),
       new  Product(16,"Dana-Ellen","http://localhost:4200/resources/images/flowers/dana-ellen.gif",
                    "orange","flower","stanza","45",5,89,"10 days","within 5 hours"),
       new  Product(17,"Dune","http://localhost:4200/resources/images/flowers/dune.gif",
                    "red","flower","stanza","45",5,89,"10 days","within 5 hours"),
       new  Product(18,"Goliath","http://localhost:4200/resources/images/flowers/goliath.gif",
                     "green","flower","stazna","45",5,89,"10 days","within 5 hours")         
    ];

  }

  ngOnInit() {

     }
}