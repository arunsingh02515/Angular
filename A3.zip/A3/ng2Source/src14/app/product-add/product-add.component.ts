import { Component, OnInit } from '@angular/core';
 
import { Product } from '../objects/product';
 
@Component({
  selector: 'create',
  templateUrl: './product-add.component.html'
})
 
 export class ProductCreateComponent implements OnInit {
   value: Product;
   
  constructor() {
  } 

  ngOnInit(): void { }

  submit(form) {
      this.value = form; 
      
  }
 
}