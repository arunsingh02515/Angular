import { Component, OnInit } from '@angular/core';
import{User} from '../objects/user';

@Component({
  selector: 'changepassword',
  templateUrl: './changepassword.component.html'
})
export class ChangePasswordComponent implements OnInit {
   value: User;

  constructor() {}
   
  ngOnInit(): void { }

  validate(form) {
        this.value = form;      
  }

  back(): void {
    
  }
}