
import { Component} from '@angular/core';

@Component({
            selector: 'tfl-store',
            template: `<shoppingcart></shoppingcart>`
          })
export class RootComponent {
          query: string;
}
