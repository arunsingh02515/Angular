import { Component, OnInit } from '@angular/core';
 
import { Product } from '../objects/product';
 
@Component({
            selector: 'delete',
            templateUrl: './product-delete.component.html'
          })
export class ProductDeleteComponent implements OnInit{
  id:number;
  product:Product;
 
  constructor() {
        this.product= new  Product(1,'Balance',
                    "http://localhost:4200/resources/images/flowers/balance.gif",
                    "red","flower","it is a flower","45",
                    5,89,"10 days","within 5 hours");          
  }

  ngOnInit():void {
                
  }
   
  yes(): void {
                
  }
  
  no(): void {
              
  }
} 