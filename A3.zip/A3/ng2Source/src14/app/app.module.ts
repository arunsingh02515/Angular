import { Component,NgModule}      from '@angular/core';

import { BrowserModule }          from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

 
 

import { RootComponent}            from './root/root.component';
import { ProductListComponent}     from './product-list/product-list.component';
import { ProductDetailComponent}   from './product-detail/product-detail.component';
import { ProductCreateComponent}   from './product-add/product-add.component';
import { ProductUpdateComponent}   from './product-update/product-update.component';
import { ProductDeleteComponent}   from './product-delete/product-delete.component';


import {ShoppingCartComponent}    from './shoppingcart/cart.component';
import {LoginComponent}           from './login/login.component';
import {RegisterComponent}        from './register/register.component';
import {ChangePasswordComponent}  from './change-password/changepassword.component';

@NgModule({
  declarations: [
                 // RootComponent,     
                 // ProductListComponent
                 // ProductDetailComponent
                  ProductCreateComponent
                 // ProductUpdateComponent
                 // ProductDeleteComponent
                 // ShoppingCartComponent
                 // LoginComponent,
                 // RegisterComponent
                 // ChangePasswordComponent  
                ],
  imports: [
                  BrowserModule,
                  FormsModule,
                  ReactiveFormsModule
          ],
   bootstrap: [ProductCreateComponent],
   providers: [
              ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch((err: any) => console.error(err));