 export class User  {
 
constructor(public userID:number,
            public  firstName:string,
            public  lastName:string,
            public  email:string,
            public  age:number,
            public  birthDate:Date,
            public  phoneNo:string,
            public  location:string,
            public  isStaff:boolean,
            public memberShip:string,
            public password:string
             ){           
 }
}