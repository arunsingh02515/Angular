import { Component,NgModule}      from '@angular/core';

import { BrowserModule }          from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule}              from '@angular/http';

import { RouterModule,Routes }    from '@angular/router';



import { LocationStrategy, HashLocationStrategy, APP_BASE_HREF} from '@angular/common';
import { routes}                  from './route';

import{AuthenticationService} from './services/authenticationService';
import{AuthService} from './services/AuthService';

import { RootComponent}            from './root/root.component';

import {HomeComponent}          from './root/HomeComponent';
import {AboutComponent}         from './root/AboutComponent';
import {ContactComponent}       from './root/ContactComponent';
import {ProtectedComponent}     from './root/ProtectedComponent';
import {LoginComponent}     from './root/LoginComponent';
import {LoggedInGuard}          from './guards/loggedIn.guard';


@NgModule({
  declarations: [
                  RootComponent,     
                  HomeComponent,
                  AboutComponent,
                  ContactComponent,
                  ProtectedComponent,
                  LoginComponent
                 
                ],
  imports: [
                  BrowserModule,
                  HttpModule,
                  FormsModule,
                  ReactiveFormsModule,
                  RouterModule.forRoot(routes)
          ],
   bootstrap: [RootComponent],
   providers: [
            
                  AuthenticationService,
                  AuthService,
                  LoggedInGuard,
                  {provide:APP_BASE_HREF,useValue:'/'},
                  {provide:LocationStrategy,useClass:HashLocationStrategy}
              ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch((err: any) => console.error(err));