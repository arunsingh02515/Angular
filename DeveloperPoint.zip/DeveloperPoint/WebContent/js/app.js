
var App = angular.module('PMApp' , ['ui.router']);


App.config(function($stateProvider, $urlRouterProvider) {
    
	
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
    
       
        .state('home', {
            url: '/home',
           
            views:{
      		  '':{templateUrl: 'views/main.html'},
      		
      		  
      	  }
            
        })
      .state('angular',{
    	  views:{
    		  '' : {templateUrl: 'angular/angular.html',controller: mainController	},
    		  'angularAbout@angular': { templateUrl: 'angular/angularAbout.html'},
    		 
    		  
    	  }
    		  })
    	  
      .state('angular.angularcontroller',{
    	url:'/angularcontroller',
    	templateUrl:'angular/angularController.html',
    	controller: angularController
    		
    })
    .state('angular.angularAboutlink',{
    	url:'/angularAboutlink',
    	templateUrl:'angular/angularAbout.html'
    		
    })
     .state('angularDetails',{
    	 url: '/:id',
        
         views: {
             '': {
                 templateUrl: 'angular/angularDetails.html',
                 controller: detailController
                        
             },
     
         },
     'angular' : {templateUrl: 'angular/angular.html',controller: mainController	}
    	    		
    })
        
   /* .state('angular.angularAbout1',{
    	url:'/angularAbout1',
    	templateUrl:'angular/angularAbout.html'
    		
    }); */   

});
App.directive('confirmOnExit', function() {
    return {
        link: function($scope, elem, attrs) {
            window.onbeforeunload = function(){
                if ($scope.myForm.$dirty) {
                    return "The form is dirty, do you want to stay on the page?";
                }
            }
            $scope.$on('$locationChangeStart', function(event, next, current) {
                if ($scope.myForm.$dirty) {
                   console.log("do u want unchange");
                   evt.preventDefault();
                }
            });
        }
    };
});
App.run(function($rootScope, $urlRouter) {
       $rootScope.$on('$stateChangeStart', function (event, next, toParams) {
    	console.log("hello1..........");
    	if(next.name!="angularAboutlink"){
    		if(document.getElementById("mm")!=null)
    		document.getElementById("mm").style.display = 'none';
    	}
    	
    });
    });

