import * as o from './output_ast';
export declare const QUOTED_KEYS: string;
export declare function convertValueToOutputAst(value: any, type?: o.Type): o.Expression;
