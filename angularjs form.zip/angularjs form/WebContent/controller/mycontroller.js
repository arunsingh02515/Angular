var module = angular.module('myapp', []);
module.controller("controller", function($scope) {
	$scope.login=function(){
		//$scope.submitted=true;
		alert($scope.user.firstName);
		//$scope.concate="detail are inputted::"+$scope.name+""+$scope.Email+""+$scope.password;
	}
	
});
		
		
		