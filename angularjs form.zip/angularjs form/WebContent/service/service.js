module.factory('MyService', function ($http) {
    
	return {
		
		submit: function(myurl,dataObj){
			return $http.post(myurl,dataObj);
		},
	};
	})