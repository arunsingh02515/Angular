package com.web.service;

import com.web.model.Customer;

public class SpringServiceImpl implements SpringService {
	public void register(Customer cust){
		
	}
}
