package com.web.service;

import com.web.model.Customer;

interface  SpringService {
	public void register(Customer cust);
}
