package com.web.dao;

import com.web.model.Customer;

public interface SpringServiceDao {
public void register(Customer cust);
}
