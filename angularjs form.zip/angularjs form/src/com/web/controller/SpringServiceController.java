package com.web.controller;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//import com.javahonk.controller.Person;
import com.programmingfree.springservice.dao.UserService;
import com.programmingfree.springservice.domain.Company;
import com.programmingfree.springservice.domain.User;


@RestController
//@RequestMapping("/service/user/")
public class SpringServiceController {
	
	@RequestMapping(value = "/PostService", method = RequestMethod.POST ,produces={"application/json"})
	public @ResponseBody String PostService(@RequestBody User user) {
		
		userService.addUser(user);
		return "successfully submitted"; 
	}

}
