 
import {Component} from '@angular/core';

@Component({
  selector: 'interest',
  template: `<h3>Interest page</h3>`
})
export class InterestComponent {
}
