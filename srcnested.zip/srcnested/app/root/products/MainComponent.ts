 
import {Component} from '@angular/core';

@Component({
  selector: 'main',
  template: `Welcome to the products section. Please select a product above.`
})
export class MainComponent {
}
