 
import {Component} from '@angular/core';

@Component({
  selector: 'flower',
  template: `<h3>Flower page</h3>`
})
export class FlowerComponent {
}
