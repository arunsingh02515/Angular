
import {Component} from '@angular/core';

@Component({
  selector: 'home',
  template: `<h2>Welcome!</h2>`
})
export class HomeComponent {
}
