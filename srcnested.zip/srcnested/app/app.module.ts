import { Component,NgModule}      from '@angular/core';

import { BrowserModule }          from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { RouterModule,Routes }    from '@angular/router';
import { LocationStrategy, HashLocationStrategy, APP_BASE_HREF} from '@angular/common';
import { routes}                  from './route';

import { RootComponent}            from './root/root.component';
import { HomeComponent}            from './root/HomeComponent';
import { MainComponent}            from './root/products/MainComponent';
import { ProductsComponent}        from './root/ProductsComponent';
import { InterestComponent}        from './root/products/InterestComponent';
import { FlowerComponent}        from './root/products/FlowerComponent';
import { ByIdComponent}            from './root/products/ByIdComponent';

@NgModule({
  declarations: [
                  RootComponent, HomeComponent, ProductsComponent,
                  MainComponent, InterestComponent, FlowerComponent,ByIdComponent             
                ],
  imports: [
                  BrowserModule,FormsModule,ReactiveFormsModule,
                  RouterModule.forRoot(routes)
          ],
   bootstrap: [RootComponent],
   providers: [           
                  {provide:APP_BASE_HREF,useValue:'/'},
                  {provide:LocationStrategy,useClass:HashLocationStrategy}
              ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch((err: any) => console.error(err));