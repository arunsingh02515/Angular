package com.inheritance;

import javax.persistence.CascadeType;
import javax.persistence.Column;  
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;  
  
@Entity  
 
@DiscriminatorValue("Bike")  
public class TwoWheeler extends Vehicle   
{  
        @Column(name="STEERING_TYPE")  
        private String steeringTwoWheeler;  
      @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
      @JoinColumn(name="studentId")
        private Student student;

       public Student getStudent() {
       	return student;
       }

       public void setStudent(Student student) {
       	this.student = student;
       } 
 public String getSteeringTwoWheeler()  
 {  
  return steeringTwoWheeler;  
 }  
  
 public void setSteeringTwoWheeler(String steeringTwoWheeler)   
 {  
  this.steeringTwoWheeler = steeringTwoWheeler;  
 } 
 
 
}  
