package com.inheritance;

public class Representation {
	private String vehicleName; 
	 private String steeringTwoWheeler;
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public String getSteeringTwoWheeler() {
		return steeringTwoWheeler;
	}
	public void setSteeringTwoWheeler(String steeringTwoWheeler) {
		this.steeringTwoWheeler = steeringTwoWheeler;
	}
	public Representation(String vehicleName, String steeringTwoWheeler) {
		//super();
		this.vehicleName = vehicleName;
		this.steeringTwoWheeler = steeringTwoWheeler;
	}  
	 
	 
}
