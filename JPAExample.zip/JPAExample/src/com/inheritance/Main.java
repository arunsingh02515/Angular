package com.inheritance;

import java.util.List;

import javax.persistence.EntityManager;
//import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
//import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistryBuilder;

public class Main {
	//static SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();  
	//static  Session session = sessionFactory.openSession(); 
	 public static void main(String args[])
	{  
		 System.out.println("Hello1");
		
		// Vehicle vehicle = new Vehicle();  
		  //vehicle.setVehicleName("Car11");  
		  EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "TestPersistence" );
	      
	      EntityManager entitymanager = emfactory.createEntityManager( );
	     //Query query = entitymanager.createQuery("Select e.vehicleName,e.steeringTwoWheeler from TwoWheeler e");
	     
	     /* TypedQuery<Long> query1 = entitymanager.createQuery(
	    	      "SELECT COUNT(c) FROM Country c", Long.class);*/
	    	 // long countryCount = query.getSingleResult();
	      Student s=new Student();
	      s.setStudentName("arun1kkk");
		  TwoWheeler twoWheeler = new TwoWheeler();  
		  twoWheeler.setVehicleName("Bike11");  
		  twoWheeler.setSteeringTwoWheeler("Bike Steering Handle");  
		  twoWheeler.setStudent(s); 
		  FourWheeler fourWheeler = new FourWheeler();  
		  fourWheeler.setVehicleName("Alto1");  
		  fourWheeler.setSteeringFourWheeler("Alto Steering Wheel");
		  entitymanager.getTransaction().begin();
		 // entitymanager.persist(vehicle);  
		  entitymanager.persist(twoWheeler);  
		  entitymanager.persist(fourWheeler);  
		 entitymanager.persist(s); 
		  entitymanager.getTransaction().commit(); 
		  Query q =  entitymanager.createQuery("SELECT e.vehicleName,e.steeringTwoWheeler,e.student FROM TwoWheeler e");
	      List<Object> list = q.getResultList( );
	      for(Object e1:list) {
	    	  Representation e=(Representation)e1;
	         System.out.println("Employee NAME :"+e.getVehicleName()+e.getSteeringTwoWheeler());
	      }
		  System.out.println("Hello1");
	 }
		 
		 
	
		}  

