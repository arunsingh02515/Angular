package com.mapping.onetomany;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;



@Entity
@Table(name = "STUDENT",catalog="arun")
public class Student {
	 @Id
		@GenericGenerator(name="kaugen" , strategy="increment")
		 @GeneratedValue(generator="kaugen")
		@Column(name = "STUDENT_ID")
	private long studentId;
	 @Column(name = "STUDENT_NAME", nullable = false, length = 100) 
	private String studentName;
	

	//private Address studentAddress;
	@OneToOne(fetch=FetchType.LAZY)
	 @JoinColumn(name="employeeId", referencedColumnName="empId" )
	private EmployeeEntity employeeEntity;
	
	
	public EmployeeEntity getEmployeeEntity() {
		return employeeEntity;
	}

	public void setEmployeeEntity(EmployeeEntity employeeEntity) {
		this.employeeEntity = employeeEntity;
	}

	public Student() {
	}

	/*public Student(String studentName, Address studentAddress) {
		this.studentName = studentName;
		this.studentAddress = studentAddress;
	}
	*/
  
	public long getStudentId() {
		return this.studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	
	public String getStudentName() {
		return this.studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	/*@ManyToOne(cascade = CascadeType.ALL)
	public Address getStudentAddress() {
		return this.studentAddress;
	}

	public void setStudentAddress(Address studentAddress) {
		this.studentAddress = studentAddress;
	}
*/
}
