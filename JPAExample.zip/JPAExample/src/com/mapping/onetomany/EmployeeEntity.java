package com.mapping.onetomany;

import java.io.Serializable;
import java.util.Set;
 
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

import com.inheritance.Student;
 
@Entity //(name = "ForeignKeyAssoEntity")
@Table(name = "EmployeeEntity")

public class EmployeeEntity implements Serializable {
 
    private static final long serialVersionUID = -1798070786993154676L;
 
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen")
   @Column(name = "empId", unique = true, nullable = false)
    private Integer employeeId;
 
    @Column(name = "email1", unique = true, nullable = false, length = 100)
    private String email;
 
    @Column(name = "firstName1", unique = false, nullable = false, length = 100)
    private String firstName;
 
    @Column(name = "lastName1", unique = false, nullable = false, length = 100)
    private String lastName;
 
    @OneToMany( cascade=CascadeType.ALL)
    @JoinColumn(name="EMPLOYEE_ID" ,referencedColumnName="empId")
    private Set<AccountEntity> accounts;
    
    @OneToOne(cascade = CascadeType.ALL ,targetEntity=Student.class,mappedBy="employeeEntity")
   // @JoinColumn(name="employeeId", referencedColumnName="empId" )
    private Student student1;
    public Student getStudent() {
		return student1;
	}

	public void setStudent(Student student1) {
		this.student1 = student1;
	}

	public Integer getEmployeeId() {
        return employeeId;
    }
 
    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }
 
    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }
 
    public String getFirstName() {
        return firstName;
    }
 
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
 
    public String getLastName() {
        return lastName;
    }
 
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
 
    public Set<AccountEntity> getAccounts() {
        return accounts;
    }
 
    public void setAccounts(Set<AccountEntity> accounts) {
        this.accounts = accounts;
    }
}
