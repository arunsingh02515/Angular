package com.mapping.onetomany;


import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.*;  
import org.hibernate.cfg.*;


public class Client {
 public static void main(String args[]){
	 System.out.println("Hello1");
		
		// Vehicle vehicle = new Vehicle();  
		  //vehicle.setVehicleName("Car11");  
		  EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "TestPersistence" );
	      
	      EntityManager entitymanager = emfactory.createEntityManager( );
	      
	   /*// Transaction t=entitymanager.beginTransaction(); 
	    AccountEntity account1 = new AccountEntity();
        account1.setAccountNumber("Account detail 71");
 
        AccountEntity account2 = new AccountEntity();
        account2.setAccountNumber("Account detail 711");
 
        AccountEntity account3 = new AccountEntity();
        account3.setAccountNumber("Account detail 311");
 
        //Add new Employee object
        EmployeeEntity firstEmployee = new EmployeeEntity();
        firstEmployee.setEmail("arunksingh@mail.com");
        firstEmployee.setFirstName("arun81");
        firstEmployee.setLastName("kumar1");
 
        EmployeeEntity secondEmployee = new EmployeeEntity();
        secondEmployee.setEmail("demo-user-second@mail.com");
        secondEmployee.setFirstName("demo-two1");
        secondEmployee.setLastName("user-two1");
 
        Set<AccountEntity> accountsOfFirstEmployee = new HashSet<AccountEntity>();
        accountsOfFirstEmployee.add(account1);
        accountsOfFirstEmployee.add(account2);
 
        Set<AccountEntity> accountsOfSecondEmployee = new HashSet<AccountEntity>();
        accountsOfSecondEmployee.add(account3);
 
        firstEmployee.setAccounts(accountsOfFirstEmployee);
        secondEmployee.setAccounts(accountsOfSecondEmployee);
        //Save Employee
        entitymanager.getTransaction().begin();
        entitymanager.persist(firstEmployee);
        
        entitymanager.persist(secondEmployee);
        entitymanager.getTransaction().commit();  */
	     // javax.persistence.Query query =  entitymanager.createQuery("SELECT distinct e FROM EmployeeEntity e join AccountEntity a");
	      javax.persistence.Query query =  entitymanager.createQuery("SELECT  e FROM EmployeeEntity e join Student s");
	      List<EmployeeEntity> list = (List<EmployeeEntity>) ( query).getResultList();
	      Set<AccountEntity> set=list.get(0).getAccounts();
	      Iterator<AccountEntity> it=set.iterator();
	      while(it.hasNext()){
	    	  System.out.println(it.next());
	      }
	      System.out.println();
	    System.out.print("success");
	    entitymanager.close();
	    
	      
	 
 }
}
