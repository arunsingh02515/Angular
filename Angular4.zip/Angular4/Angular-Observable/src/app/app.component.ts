import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
		   <app-book></app-book>
    `
})
export class AppComponent {
  title = 'Angular-Observable';
}
