import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, filter, scan } from "rxjs/operators";
import { Book } from './book';

@Injectable()
export class BookService {
    bookUrl = "/api/books";	

	constructor(private http: HttpClient) { }

    getBooksFromStore(): Observable<Book[]> {
        return this.http.get<Book[]>(this.bookUrl);
    }
    getFavBookFromStore(id: number): Observable<Book> {
        return this.http.get<Book>(this.bookUrl + "/" + id);
    } 
    getData(): Observable<any> {
        return this.http.get(this.bookUrl)
        .pipe(map(result => result))
    }  
    getItems() {
        this.http.get(this.bookUrl).pipe(map((b: Book) => b)).subscribe(result => {
          console.log("hllo"+result);
        });
      } 

      
           
}