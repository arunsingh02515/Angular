import { Component, OnInit } from '@angular/core';
import { Observable,of } from "rxjs"
import { map, filter, scan } from "rxjs/operators";
import { HttpErrorResponse } from '@angular/common/http';
import { BookService } from './book.service';
import { Book } from './book';

@Component({
   selector: 'app-book',
   templateUrl: './book.component.html'
})
export class BookComponent implements OnInit { 
   allBooks$: Observable<Book[]>;
   favBook$: Observable<Book>;
   //myAllfavBooks$: Observable<Book[]>;
   favBookName$: Observable<string>; 
   //similarBooks$: Observable<Book[]>; 
   softBooks: Book[];
   //allFavBooks: Book[];
   bookName: string | {};
   //similarFavBooks: Book[];

   constructor(private bookService: BookService) { }
   
   ngOnInit() {
        this.getBooks();	
        this.getFavBook();
        this.getsoftBooks();
        this.bookService.getItems();
        console.log("book"+this.getBookName());
        //this.getAllFavBooks();
        //this.getBookName();
   }
   getBooks() {
        this.allBooks$ = this.bookService.getBooksFromStore();
        const nums = of(1, 2, 3);
 
const squareValues = map((val: number) => val * val);
const squaredNums = squareValues(nums);
 
squaredNums.subscribe(x => console.log(x));
   }
   getFavBook() {
        this.favBook$ = this.bookService.getFavBookFromStore(101); 
   }
   getsoftBooks() {
    this.bookService.getBooksFromStore().subscribe(books => {
       this.softBooks = books
    },
    (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
            //A client-side or network error occurred.
            console.log('An error occurred:', err.error.message);
        } else {
            //Backend returns unsuccessful response codes such as 404, 500 etc.
            console.log('Backend returned status code: ', err.status);
            console.log('Response body:', err.error);
        }
     }
    );
    
}
getBookName() {
    //this.favBookName$ = this.bookService.getFavBookFromStore(101).pipe(map(book=> book.name));  
    // Using subscribe
    this.bookService.getFavBookFromStore(101).pipe(
    map(book=> {
      //if(book.name.length < 15) {
         return book.name;
      //} else {
         //throw('Length less than 15');
      //}
    }))
    
    
    /*.catch(error => {
      console.log(error);
      //return of("Default Name");
      throw(error.message || error);
    }) */
    .subscribe(name=> {
        this.bookName = name;
        console.log("kk"+name);
      },
      err => {
        console.log(err);
      }
    );
}
   }
