export interface Book {
   id: number;
   name: string;
   category: string;
}