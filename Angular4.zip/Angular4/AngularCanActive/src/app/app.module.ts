import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { DashboardLayoutComponent }  from './layout/dashboard.layout.component';
import { AddressComponent }  from './address/address.component';
import { LogoutComponent } from './authentication/logout.component';
import { AuthGuardService } from './authentication/services/auth-guard.service';
import { AuthService } from './authentication/services/auth.service';
import {AppComponent} from './app.component';
@NgModule({
  declarations: [DashboardLayoutComponent,
		AddressComponent,
		LogoutComponent,
        AppComponent
                 ],
  bootstrap:    [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [AuthGuardService,AuthService],
  
})
export class AppModule { }
