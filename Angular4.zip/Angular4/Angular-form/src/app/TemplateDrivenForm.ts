import { Component } from '@angular/core';

@Component({
    selector: "template-driven-form",
    templateUrl: 'template-driven-form.html'
})
export class TemplateDrivenForm {

    //user: Object = {};
	user = {
    firstName: 'John',
    password:  'test'
};

    onSubmitTemplateBased() {
        console.log(this.user);
    }

}