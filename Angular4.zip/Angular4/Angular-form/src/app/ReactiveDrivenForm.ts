import { FormGroup, FormControl, Validators, FormBuilder } 
    from '@angular/forms';
import { Component } from '@angular/core';

@Component({
    selector: "reactive-driven-form",
    templateUrl: 'reactive-driven-form.html'
})
export class ReactiveDrivenForm {
    form1: FormGroup;
    
    firstName = new FormControl("", Validators.required);
    
    constructor(fb: FormBuilder) {
        this.form1 = fb.group({
            "firstName": this.firstName,
            "password":["", Validators.required]
        });
    }
    onSubmit() {
        console.log("model-based form submitted");
        console.log(this.form1);
    }
}