import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveDrivenForm } from './ReactiveDrivenForm';
import {ReactiveFormsModule} from "@angular/forms";
@NgModule({
  declarations: [AppComponent,ReactiveDrivenForm
                 ],
  bootstrap:    [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
	ReactiveFormsModule
  ],
  providers: [],
  
})
export class AppModule { }
