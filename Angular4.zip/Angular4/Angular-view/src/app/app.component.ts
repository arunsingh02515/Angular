import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
			   <app-number-parent></app-number-parent>
			   <app-cptheme></app-cptheme>
			   
             `
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular-Input-Output';
}
