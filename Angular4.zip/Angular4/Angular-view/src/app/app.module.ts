import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NumberComponent }  from './number.component';
import { NumberParentComponent }  from './number-parent.component';
import { CpThemeComponent }  from './cptheme.component';
@NgModule({
  declarations: [AppComponent,NumberComponent,NumberParentComponent,CpThemeComponent
                 ],
  bootstrap:    [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  
})
export class AppModule { }
