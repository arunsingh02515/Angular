export class Student {
   constructor(public fname?: string, public lname?: string) { 
   }
}