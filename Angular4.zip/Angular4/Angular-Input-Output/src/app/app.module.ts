import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ParentComponent}  from './parent.component';
import {ChildOneComponent}  from './childone.component';
import {ChildTwoComponent}  from './childtwo.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [ParentComponent, 
                 ChildOneComponent,
				 ChildTwoComponent],
  bootstrap:    [ParentComponent],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  
})
export class AppModule { }
